import Homepage from './Component/Homepage/Homepage.js';
import Editpage from './Component/Homepage/Editpage.js'
// import  axios  from "axios";
 import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Component } from "react";
class App extends Component{
  render(){
    return(
      <>
        <Homepage/>
      
      </>
    )
  }
}

export default App;
