import React, { useState, useEffect } from "react";
import axios from "axios";
import moduleCss from '../Homepage/Homepage.module.css'


function HomePage() {
 
  const [data, setData] = useState([]);
  const  [newData,SetNewData] = useState({});
  const [index,setIndex] = useState();
  
  function getData(id,i) {
    axios
      .get(`https://jsonplaceholder.typicode.com/posts/${id}`)
      .then((response) => {
        SetNewData(response.data);
      })
      .catch((err) => console.log(err));
  }

  useEffect(() => {
    getData();
  }, []);
  const handelDelte = (id) => {
    axios
      .delete(`https://jsonplaceholder.typicode.com/posts/${id}`)
      .then((res) => {
        const updatedPosts = data.filter((post) => post.id !== id);
        setData(updatedPosts);
      })
      .then(() => alert("Post Deleted!"))
      .catch((err) => console.log(err));
  };

  const handleChange = (e) =>{
     const name = e.target.name;
     const value = e.target.value;

     SetNewData({...newData, [name]:value});
  };
  


  const handelSubmmit = (e)=>{
    // POST => url,newData
    axios.post(`https://jsonplaceholder.typicode.com/posts`,newData)
    .then(res=>{
      // push newData to data(state object)
        //arr.push(newdata);
        const newDataArr = [...data];
        newDataArr.push(res.data);
        setData(newDataArr)

    })
    .catch(err=>console.log(err));
    e.preventDefault();
    console.log(newData);
    
  }

    const handleUpdate =(id)=>{
       axios.put(`https://jsonplaceholder.typicode.com/posts ${id}`)
       .then(res=>{
          
       })
    }
  

  return (
    <div>
    
      <div className="text-center">
        <form onSubmit={handelSubmmit} className="table">
          <br />
          <br />
          <input type="text" placeholder="title"  name="title" onChange={handleChange}  />
          <br />
          <br />
          <textarea cols="23" rows="3"  name="description"  onChange={handleChange}></textarea>
          <br />
          <br />
          <input type="submit" value="submit" class="btn btn-outline-primary" /> <button class="btn btn-outline-danger">Cancle</button>
          <br />
        </form>
      </div>
      {data.map((value, index) => (
        <div key={index} className={moduleCss.main}>
          <div>
            {value.title}{" "}
            <span className={moduleCss.fr}>
              <i class="fa fa-trash" onClick={() =>{
                if(  window.confirm("Are you Sure To Delete Data?")){
                  handelDelte(value.id)

                }
              } }></i>
             
              <i className="fa fa-edit" onClick={()=>{
                if(window.confirm("Are you sure To edit?")){
                  handleUpdate(value.id,index)
                }
              } }></i>
              
              
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}

export default HomePage;
